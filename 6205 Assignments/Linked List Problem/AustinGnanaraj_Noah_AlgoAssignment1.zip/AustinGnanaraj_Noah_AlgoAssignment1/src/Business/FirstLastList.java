/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author AustinGnanaraj
 */
class FirstLastList {

    private Link first;
    private Link last;

    public FirstLastList() {
        first = null;
        last = null;
    }

    public boolean isEmpty() {
        return first == null;
    }

    public void insertLast(int dd, int pos, long timeAdded) {
        Link newLink = new Link(dd, pos, timeAdded);
        if (isEmpty()) {
            first = newLink;

        } else {
            last.next = newLink;
        }
        last = newLink;

    }

    public Link deleteFirst(long timeRemoved) {
        Link tempLink = first;
        if (first.next == null) {
            first.timeRemoved = timeRemoved;
            last = null;

        }
        first.timeRemoved = timeRemoved;
        first = first.next;
        return tempLink;
    }

    public String toString() {
        String str = "";
        Link current = first;
        while (current != null) {
            str += current.toString();
            current = current.next;
        }
        return str;
    }

}
