/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author AustinGnanaraj
 */
class Link {

    public int data;
    public Link next;
    public long timeAdded;
    public long timeRemoved;
    public int position;

    public Link(int data, int pos, long timeAdded) {
        this.data = data;
        this.position = pos;
        this.timeAdded = timeAdded;

    }

    @Override
    public String toString() {
        return " -|| Data: " + data + ";" + " " + " Position" + position + "; " + " WaitTime " + (waitTime(timeAdded, timeRemoved)) + "||- CreatedTime: " + timeAdded + " $ ProcessedTime: " + timeRemoved +"\n";
    }

    public String waitTime(long t1, long t2) {
        if (t1 == 0 || t2 == 0) {
            return " Unknown ";
        } else {
            return String.valueOf(t2 - t1);
        }
    }

}
