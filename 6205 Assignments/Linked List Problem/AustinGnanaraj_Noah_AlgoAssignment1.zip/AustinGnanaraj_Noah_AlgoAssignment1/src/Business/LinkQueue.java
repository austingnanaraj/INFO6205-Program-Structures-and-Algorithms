/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author AustinGnanaraj
 */
class LinkQueue {

    private FirstLastList theList;
    private int position;

    public LinkQueue() {
        theList = new FirstLastList();
    }

    public boolean isEmpty() {
        return theList.isEmpty();
    }

    public void insert(int j, int pos) {
        theList.insertLast(j, pos, System.currentTimeMillis());
        this.position = pos;
    }

    public Link remove() {
        return theList.deleteFirst(System.currentTimeMillis());

    }

    public String toString() {
        return theList.toString();
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    private long currentTime() {
        long start_time = System.nanoTime();
        return start_time;
    }
}
