/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import static java.lang.Math.round;

/**
 *
 * @author AustinGnanaraj
 */
public class Main {

    int cycles;

    public LinkQueue main(int s) {
        LinkQueue theQueue = new LinkQueue();
        cycles = s;
        int queueNo = 1;
        for (int i = 0; i < cycles - 1; i++) {
            double cc = round((Math.random() * 3) + 1);
            System.out.println("Number of server calls : " + cc);
            for (int t = 0; t < cc; t++) {
                if (theQueue.isEmpty() == false) {
                    Link d = theQueue.remove();
                    System.out.println("Process: " + (t + 1) + " :" + d);
                } else {
                    System.out.println("Queue is Empty");
                }
            }
            int c = round((int) (Math.random() * 3) + 0);
            System.out.println("No. of Elements to be added into the Queue: " + c);
            switch (c) {
                case 1:
                    theQueue.insert((int) (Math.random() * 40) + 5, queueNo++);
                    System.out.println("One Element added into Queue");
                    break;
                case 2:
                    for (int ii = 0; ii < 2; ii++) {
                        theQueue.insert((int) (Math.random() * 40) + 5, queueNo++);
                    }
                    System.out.println("Two Elements added into Queue");
                    break;
                case 3:
                    for (int ii = 0; ii < 3; ii++) {
                        theQueue.insert((int) (Math.random() * 40) + 5, queueNo++);
                    }
                    System.out.println("Three Elements added into Queue");
                    break;
                case 0:
                    break;
            }
            System.out.println(theQueue);
        }
        return theQueue;
    }

}
