/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithm_assignment5;

import static java.lang.Math.abs;

/**
 *
 * @author AustinGnanaraj
 */
/**
 *
 * Java Program to implement Linear Probing Hash Table
 *
 *
 */
/**
 * Class LinearProbingHashTable *
 */
class LinearProbingHashTable {

    private int currentSize, maxSize;

    private String[] keys;

    /**
     * Constructor *
     */
    public LinearProbingHashTable(int capacity) {

        currentSize = 0;

        maxSize = capacity;

        keys = new String[maxSize];

    }

    /**
     * Function to clear hash table *
     */
    public void makeEmpty() {

        currentSize = 0;

        keys = new String[maxSize];

    }

    /**
     * Function to get size of hash table *
     */
    public int getSize() {

        return currentSize;

    }

    public int getMaxSize() {

        return maxSize;

    }

    /**
     * Function to check if hash table is full *
     */
    public boolean isFull() {

        return currentSize == maxSize;

    }

    /**
     * Function to check if hash table is empty *
     */
    public boolean isEmpty() {

        return getSize() == 0;

    }

    /**
     * Fucntion to check if hash table contains a key *
     */
    public boolean contains(String key) {

        return get(key) != null;

    }

    /**
     * Function to get hash code of a given key *
     */
    private int hash(String key) {
        int asciiValue = 0;
        for (int i = 0; i < key.length(); i++) {
            char character = key.charAt(i);
            int ascii = (int) character;
            asciiValue = asciiValue + ascii;
        }
        return asciiValue % maxSize;

    }

    /**
     * Function to insert key-value pair *
     */
    public void insert(String key) {

        int tmp = hash(key);

        int i = abs(tmp);

        do {
            if (keys[i] == null) {
                keys[i] = key;

                currentSize++;
                return;

            }

            if (keys[i].equals(key)) {

                return;

            }

            i = (i + 1) % maxSize;

        } while (i != tmp);

    }

    public void check(int a) {
        if (currentSize >= ((maxSize * a) / 100)) {
            resizing();
        }
    }

    /**
     * Function to get value for a given key *
     */
    public void resizing() {
        String[] oldArray = keys;
        keys = new String[maxSize * 2];
        maxSize = maxSize * 2;
        // System.out.println("New Size" + maxSize);
        for (int i = 0; i < oldArray.length; i++) {
            if (oldArray[i] != null) {
                insert(oldArray[i]);
            }
        }

    }

    public String get(String key) {

        int i = hash(key);

        while (keys[i] != null) {

            if (keys[i].equals(key)) {

            }

            i = (i + 1) % maxSize;

        }

        return null;

    }

    /**
     * Function to print HashTable *
     */
    public void printHashTable() {

        System.out.println("\nHash Table: ");

        for (int i = 0; i < maxSize; i++) {
            if (keys[i] != null) {
                System.out.println(i + " Position " + keys[i]);
            }
        }

        System.out.println();

    }

}
