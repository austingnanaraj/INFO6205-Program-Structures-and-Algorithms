/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithm_assignment5;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

/**
 *
 * @author AustinGnanaraj
 */
public class LinearProbingHashTableTest {

    public static void main(String[] args) throws IOException {
        String[] docs = {"C:/file/file.txt", "C:/file/file1.txt"};
        HashMap<String, TreeMap<String, Integer>> wordToDocumentMap = new HashMap<>();
        for (String currentDocument : docs) {
            for (String line : Files.readAllLines(Paths.get(currentDocument))) {// line by line processing
                for (String currentWord : line.split(" ")) { // spliting the line by " "
                    TreeMap<String, Integer> documentToCountMap = new TreeMap<>();

                    documentToCountMap = wordToDocumentMap.get(currentWord);

                    if (documentToCountMap == null) {

                        documentToCountMap = new TreeMap<>();
                        wordToDocumentMap.put(currentWord, (TreeMap<String, Integer>) documentToCountMap);
                    }
                    Integer currentCount = documentToCountMap.get(currentDocument);
                    if (currentCount == null) {

                        currentCount = 0;
                    }
                    documentToCountMap.put(currentDocument, currentCount + 1);
                }
            }
        }

        long startTime, endTime;
        long totalTime = 0;
        int counter = 0;
        String[] aj = new String[wordToDocumentMap.size()];
        for (Map.Entry<String, TreeMap<String, Integer>> wordToDocument
                : wordToDocumentMap.entrySet()) {
            aj[counter] = wordToDocument.getKey();
            counter++;
        }
        for (int k = 50; k < 101; k = k + 10) {

            for (int j = 0; j < 100; j++) {
                LinearProbingHashTable lpht = new LinearProbingHashTable(50);
                startTime = System.nanoTime();
                for (int u = 0; u < 10000; u++) {
                    int idx = new Random().nextInt(aj.length);
                    String random = (aj[idx]);
                    lpht.check(k);
                    lpht.insert(random);
                }
                endTime = System.nanoTime();
                long a = endTime - startTime;
                totalTime = totalTime + a;
            }
            totalTime = totalTime / 100;
            //System.out.println("Iteration Time : Resizing at %" + k + " Time " + totalTime);
            System.out.println(k + "," + totalTime);
        }
        long finaltime = 0;
        for (int l = 100; l < 10000; l = l *2) {
            for (int j = 0; j < l; j++) {
                int idx = new Random().nextInt(aj.length);
                String random = (aj[idx]);
                startTime = System.nanoTime();
                wordToDocumentMap.containsKey(random);
                endTime = System.nanoTime();
                long temptime = endTime - startTime;
                finaltime = finaltime + temptime;
            }

            System.out.println(l + "," + finaltime);
        }
    }
}
